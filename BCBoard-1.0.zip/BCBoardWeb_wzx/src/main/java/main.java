import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.scheduler.ScheduledTask;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class main extends Plugin implements Listener {

    private String remoteVersion = "";
    private String content = "默认内容";
    private ScheduledTask scheduledTask;

    @Override
    public void onEnable() {
        getProxy().getPluginManager().registerListener(this, this);
        getProxy().getPluginManager().registerCommand(this, new MyCommand(this));
        downloadVersion();
        downloadAndAnnounce(); // 初始下载并广播
        scheduleAnnouncement(); // 定时广播
    }

    private void downloadVersion() {
        try {
            URL url = new URL("https://chirnuo.com/bcboard/ver.txt");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                Scanner scanner = new Scanner(url.openStream());
                remoteVersion = scanner.nextLine();
                scanner.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            // 无法获取版本号时，设置为一个不可能低于的版本号
            remoteVersion = "999.999.999";
        }
    }

    public class MyCommand extends Command {
        public MyCommand(Plugin plugin) {
            super("bcboard", null, "bcb");
        }

        @Override
        public void execute(CommandSender sender, String[] args) {
            if (!sender.hasPermission("bungeecordboard.command")) {
                sender.sendMessage(new TextComponent("你没有权限使用这个命令。"));
                return;
            }

            if (args.length == 0) {
                sender.sendMessage(new TextComponent("BCBoard Ver1.0 Design by Chirnuo"));
                sender.sendMessage(new TextComponent("可用参数"));
                sender.sendMessage(new TextComponent("/bcb ver 列出版本并检查更新"));
                sender.sendMessage(new TextComponent("/bcb nr 输入远程服务器上存储的内容"));
                sender.sendMessage(new TextComponent("/bcb reload 重载插件"));
                return;
            }

            switch (args[0].toLowerCase()) {
                case "ver":
                    if (remoteVersion.isEmpty()) {
                        sender.sendMessage(new TextComponent("BCBoard Ver1.0 Design by Chirnuo"));
                        sender.sendMessage(new TextComponent("https://chirnuo.com/bcboard/"));
                        sender.sendMessage(new TextComponent("无法获取远程版本号，请检查网络连接。"));
                        sender.sendMessage(new TextComponent("请始终考虑访问我们位于Github上的永久网站以获得帮助"));
                        sender.sendMessage(new TextComponent("https://github.com/Chirnuo/BCBoard"));
                    } else {
                        String pluginVersion = getDescription().getVersion();
                        sender.sendMessage(new TextComponent("BCBoard Ver1.0 Design by Chirnuo"));
                        sender.sendMessage(new TextComponent("https://chirnuo.com/bcboard/"));
                        sender.sendMessage(new TextComponent(pluginVersion.compareTo(remoteVersion) < 0 ? "已检测到有新的版本更新" : "当前已经是最新版本"));
                        sender.sendMessage(new TextComponent(pluginVersion.compareTo(remoteVersion) < 0 ? "请访问我们的网站查看更新" : "下次更新检测会在服务器重启时开启"));
                        sender.sendMessage(new TextComponent("感谢你的支持"));
                    }
                    break;
                case "reload":
                    downloadAndAnnounce();
                    sender.sendMessage(new TextComponent("内容已更新。"));
                    break;
                case "nr":
                    for (TextComponent component : formatContent(content)) {
                        sender.sendMessage(component);
                    }
                    break;
                default:
                    sender.sendMessage(new TextComponent("BCBoard Ver1.0 Design by Chirnuo"));
                    sender.sendMessage(new TextComponent("可用参数"));
                    sender.sendMessage(new TextComponent("/bcb ver 列出版本并检查更新"));
                    sender.sendMessage(new TextComponent("/bcb nr 输入远程服务器上存储的内容"));
                    sender.sendMessage(new TextComponent("/bcb reload 重载插件"));
                    break;
            }
        }


        public List<String> onTabComplete(CommandSender sender, String[] args) {
            if (args.length == 1 && sender.hasPermission("bungeecordboard.command")) {
                return List.of("ver", "reload", "nr");
            }
            return Collections.emptyList();
        }
    }

    private void downloadAndAnnounce() {
        try {
            URL url = new URL("https://chirnuo.com/serverboard.txt");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream is = con.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder builder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line).append("\n");
                }
                reader.close();
                content = builder.toString();

                // 替换 & 为 §
                content = content.replace("&", "§");

                // 向所有玩家发送消息
                for (ProxiedPlayer player : ProxyServer.getInstance().getPlayers()) {
                    for (TextComponent component : formatContent(content)) {
                        player.sendMessage(component);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void scheduleAnnouncement() {
        scheduledTask = getProxy().getScheduler().schedule(this, () -> {
            downloadAndAnnounce();
        }, 0, 60, TimeUnit.MINUTES); // 每分钟执行一次
    }

    @Override
    public void onDisable() {
        if (scheduledTask != null) {
            scheduledTask.cancel();
        }
    }

    private TextComponent[] formatContent(String content) {
        String[] lines = content.split("\n");
        TextComponent[] components = new TextComponent[lines.length];
        for (int i = 0; i < lines.length; i++) {
            components[i] = new TextComponent(lines[i]);
        }
        return components;
    }
}